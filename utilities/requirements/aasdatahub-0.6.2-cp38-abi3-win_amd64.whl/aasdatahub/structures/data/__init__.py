from aasdatahub.structures.data.base import BasicInfo
from aasdatahub.structures.data.bbox import Bbox, Bboxes
from aasdatahub.structures.data.class_label import ClassLabel
from aasdatahub.structures.data.image import FileName, Image
from aasdatahub.structures.data.mask import Mask, MaskPred

__all__ = ["Bboxes", "Bbox", "ClassLabel", "Image", "FileName", "Mask", "MaskPred", "BasicInfo"]
