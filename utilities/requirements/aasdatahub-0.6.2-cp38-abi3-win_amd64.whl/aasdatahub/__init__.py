from pkg_resources import DistributionNotFound, get_distribution

from aasdatahub.imagehub import ImageHub, ImageInferenceHub

__all__ = [
    "ImageHub",
    "ImageInferenceHub",
    "__version__",
]


try:
    __version__ = get_distribution("aasdatahub").version
except DistributionNotFound:
    # package is not installed
    pass
