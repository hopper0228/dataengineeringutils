from deeplake.core.transform.transform import (
    compute,
    compose,
    ComputeFunction,
    Pipeline,
)
