import deeplake
from deeplake.core.vectorstore.vector_search.ingestion import data_ingestion
