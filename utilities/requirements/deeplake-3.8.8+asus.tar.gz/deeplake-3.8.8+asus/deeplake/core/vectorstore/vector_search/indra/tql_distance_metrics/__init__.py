from deeplake.core.vectorstore.vector_search.indra.tql_distance_metrics.order import (
    get_order_type as get_order_type_for_distance_metric,
)
from deeplake.core.vectorstore.vector_search.indra.tql_distance_metrics.distance_metric import (
    get_tql_distance_metric,
)
