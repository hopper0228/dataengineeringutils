from enum import Enum


class DistanceType(Enum):
    L2_NORM = "l2_norm"
    COSINE_SIMILARITY = "cosine_similarity"
