from deeplake.integrations.mmdet.mmdet_ import train_detector
from mmdet.models import build_detector  # type: ignore
