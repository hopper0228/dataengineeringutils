def is_empty_list(sample):
    return isinstance(sample, list) and len(sample) == 0
