DEFAULT_IMAGE_TENSOR_PARAMS = {
    "name": "images",
    "htype": "image",
}

DEFAULT_YOLO_LABEL_TENSOR_PARAMS = {
    "name": "labels",
    "htype": "class_label",
    "sample_compression": None,
}

DEFAULT_YOLO_COORDINATES_TENSOR_PARAMS = {
    "sample_compression": None,
}
